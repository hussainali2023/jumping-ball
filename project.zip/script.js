const colorPic = (id) => {
  let color = id;
  document.body.style.backgroundColor = color;
};
